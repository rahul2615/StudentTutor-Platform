from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FileField, TextAreaField, SubmitField, SelectField, IntegerField, DateTimeLocalField
from wtforms.validators import DataRequired, Length, Optional, Email, EqualTo, NumberRange
from flask_wtf.file import FileAllowed


COURSE_CATEGORIES = [
    ('General', 'General'),
    ('Computer Science', 'Computer Science'),
    ('Mathematics', 'Mathematics'),
    ('Science', 'Science & Technology'),
    ('Languages', 'Languages & Literature'),
    ('Business', 'Business & Economics'),
    ('Arts', 'Arts & Humanities'),
]


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=150)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=150)])
    email = StringField('Email Address', validators=[Optional(), Email(), Length(max=150)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6, max=150)])
    role = SelectField('Role', choices=[('student', 'Student'), ('tutor', 'Tutor')], validators=[DataRequired()])
    submit = SubmitField('Register')


class CourseForm(FlaskForm):
    title = StringField('Course Title', validators=[DataRequired(), Length(max=255)])
    category = SelectField('Category', choices=COURSE_CATEGORIES, default='General', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    prerequisites = TextAreaField('Prerequisites', validators=[Optional()])
    duration = StringField('Duration (e.g., 4 weeks)', validators=[Optional(), Length(max=100)])
    file = FileField('Upload Course Material', validators=[FileAllowed(['pdf', 'docx', 'png', 'jpg'], 'Only PDF, DOCX, PNG, JPG allowed!')])
    submit = SubmitField('Save Course')


class EditProfileForm(FlaskForm):
    email = StringField('Email Address', validators=[Optional(), Email(), Length(max=150)])
    bio = TextAreaField('Bio / About Me', validators=[Optional(), Length(max=1000)])
    profile_pic = FileField('Profile Picture', validators=[FileAllowed(['jpg', 'jpeg', 'png', 'gif', 'webp'], 'Images only!')])
    current_password = PasswordField('Current Password (Required for Password Change)', validators=[Optional()])
    new_password = PasswordField('New Password', validators=[Optional(), Length(min=6, max=150)])
    confirm_password = PasswordField('Confirm New Password', validators=[EqualTo('new_password', message='Passwords must match')])
    submit = SubmitField('Update Profile')


class ForgotPasswordForm(FlaskForm):
    username_or_email = StringField('Username or Email', validators=[DataRequired()])
    submit = SubmitField('Send Reset Link')


class ResetPasswordForm(FlaskForm):
    password = PasswordField('New Password', validators=[DataRequired(), Length(min=6, max=150)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password', message='Passwords must match')])
    submit = SubmitField('Reset Password')


# Phase 3 Forms: Learning & Engagement
class QuizForm(FlaskForm):
    title = StringField('Quiz Title', validators=[DataRequired(), Length(max=150)])
    passing_score = IntegerField('Passing Score (%)', default=70, validators=[DataRequired(), NumberRange(min=1, max=100)])
    submit = SubmitField('Create Quiz')


class QuestionForm(FlaskForm):
    prompt = TextAreaField('Question Prompt', validators=[DataRequired()])
    option_a = StringField('Option A', validators=[DataRequired(), Length(max=255)])
    option_b = StringField('Option B', validators=[DataRequired(), Length(max=255)])
    option_c = StringField('Option C', validators=[DataRequired(), Length(max=255)])
    option_d = StringField('Option D', validators=[DataRequired(), Length(max=255)])
    correct_option = SelectField('Correct Option', choices=[('A', 'Option A'), ('B', 'Option B'), ('C', 'Option C'), ('D', 'Option D')], validators=[DataRequired()])
    submit = SubmitField('Save Question')


class LiveSessionForm(FlaskForm):
    title = StringField('Session Title', validators=[DataRequired(), Length(max=150)])
    description = TextAreaField('Session Description', validators=[Optional()])
    scheduled_at = DateTimeLocalField('Scheduled Time', format='%Y-%m-%dT%H:%M', validators=[DataRequired()])
    duration_minutes = IntegerField('Duration (Minutes)', default=60, validators=[DataRequired(), NumberRange(min=15, max=300)])
    meeting_link = StringField('Meeting URL / Jitsi Room Name', validators=[DataRequired(), Length(max=255)])
    submit = SubmitField('Schedule Live Session')


class ForumPostForm(FlaskForm):
    title = StringField('Post Title', validators=[DataRequired(), Length(max=200)])
    content = TextAreaField('Discussion Content', validators=[DataRequired()])
    submit = SubmitField('Post Discussion')


class ForumCommentForm(FlaskForm):
    content = TextAreaField('Your Reply', validators=[DataRequired()])
    submit = SubmitField('Post Reply')


class ReviewForm(FlaskForm):
    rating = SelectField('Rating', choices=[('5', '5 Stars - Excellent'), ('4', '4 Stars - Very Good'), ('3', '3 Stars - Average'), ('2', '2 Stars - Fair'), ('1', '1 Star - Poor')], validators=[DataRequired()])
    comment = TextAreaField('Course Review', validators=[Optional(), Length(max=1000)])
    submit = SubmitField('Submit Review')


class MessageForm(FlaskForm):
    content = TextAreaField('Message', validators=[DataRequired()])
    submit = SubmitField('Send Message')