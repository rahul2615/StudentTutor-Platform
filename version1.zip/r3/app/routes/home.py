from flask import Blueprint, render_template, redirect, request, session

home = Blueprint("home", __name__)


@home.route("/")
def index():
    return render_template("home.html")


@home.route("/set-language/<lang>")
def set_language(lang):
    """Switch the UI language and redirect back."""
    from flask import current_app
    supported = current_app.config.get("SUPPORTED_LANGUAGES", ["en"])
    if lang in supported:
        session["lang"] = lang
    return redirect(request.referrer or "/")


@home.route("/offline")
def offline():
    """Offline fallback page for the service worker."""
    return render_template("offline.html")