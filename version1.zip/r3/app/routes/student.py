from flask import Blueprint
from app.controllers.student_controller import dashboard, courses, enroll, unenroll
from app.controllers.course_controller import take_quiz, view_certificate

student = Blueprint("student", __name__)

# Routes for Student Dashboard and Courses Page
student.route("/dashboard")(dashboard)
student.route("/courses", methods=["GET"])(courses)
student.route("/enroll/<int:course_id>", methods=["POST"])(enroll)
student.route("/unenroll/<int:course_id>", methods=["POST"])(unenroll)

# Quizzes & Certificates
student.route("/quiz/<int:quiz_id>", methods=["GET", "POST"])(take_quiz)
student.route("/certificate/<int:course_id>", methods=["GET"])(view_certificate)
