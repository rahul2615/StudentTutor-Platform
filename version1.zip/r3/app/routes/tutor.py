from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from app.models import Course
from app.decorators import tutor_required

from app.controllers.course_controller import (
    create_course as create_course_func,
    edit_course as edit_course_func,
    delete_course as delete_course_func,
    view_courses,
    course_details,
    download_material,
    create_quiz as create_quiz_func,
    add_question as add_question_func,
    schedule_live_session as schedule_session_func,
)

tutor_bp = Blueprint("tutor", __name__)


@tutor_bp.route("/dashboard")
@tutor_required
def dashboard():
    """Tutor Dashboard Route."""
    page = request.args.get('page', 1, type=int)
    tutor_courses_pagination = Course.query.filter_by(tutor_id=current_user.id).paginate(page=page, per_page=6, error_out=False)
    return render_template('tutor/dashboard.html', courses_pagination=tutor_courses_pagination)


@tutor_bp.route("/create_course", methods=["GET", "POST"])
@tutor_required
def handle_create_course():
    """Handles Course Creation for Tutors."""
    return create_course_func()


@tutor_bp.route("/edit_course/<int:course_id>", methods=["GET", "POST"])
@login_required
def handle_edit_course(course_id):
    """Handles Course Editing for Tutors."""
    return edit_course_func(course_id)


@tutor_bp.route("/delete_course/<int:course_id>", methods=["POST"])
@login_required
def handle_delete_course(course_id):
    """Handles Course Deletion for Tutors."""
    return delete_course_func(course_id)


# Download/View course material
@tutor_bp.route("/materials/download/<int:material_id>")
@login_required
def handle_download_material(material_id):
    return download_material(material_id)


# Quiz creation & question addition
@tutor_bp.route("/course/<int:course_id>/quiz/create", methods=["GET", "POST"])
@login_required
def handle_create_quiz(course_id):
    return create_quiz_func(course_id)


@tutor_bp.route("/quiz/<int:quiz_id>/add_question", methods=["GET", "POST"])
@login_required
def add_question(quiz_id):
    return add_question_func(quiz_id)


# Schedule Live Session
@tutor_bp.route("/course/<int:course_id>/schedule_session", methods=["GET", "POST"])
@login_required
def schedule_session(course_id):
    return schedule_session_func(course_id)


# View all approved courses
tutor_bp.route("/courses", methods=["GET"])(view_courses)

# View course details
tutor_bp.route("/course/<int:course_id>", methods=["GET"])(course_details)
